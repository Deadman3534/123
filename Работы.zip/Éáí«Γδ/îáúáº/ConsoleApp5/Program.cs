﻿using System;
using System.Collections.Generic;

public class Product
{
    public string Name { get; set; }
    public decimal Price { get; set; }

    public Product(string name, decimal price)
    {
        Name = name;
        Price = price;
    }
}

public class Customer
{
    public string Name { get; set; }
    public decimal Money { get; set; }
    public List<Product> Cart { get; set; }
    public List<Product> Package { get; set; }

    public Customer(string name, decimal money)
    {
        Name = name;
        Money = money;
        Cart = new List<Product>();
        Package = new List<Product>();
    }

    public void AddProductToCart(Product product)
    {
        Cart.Add(product);
        Console.WriteLine($"Покупатель {Name} добавил в корзину товар {product.Name}.");
    }

    public void BuyProducts()
    {
        decimal totalCost = 0;
        foreach (var product in Cart)
        {
            totalCost += product.Price;
        }

        if (Money >= totalCost)
        {
            Money -= totalCost;
            Console.WriteLine($"Покупатель {Name} купил товары на сумму {totalCost}.");
        }
        else
        {
            decimal remainingMoney = Money;
            List<Product> productsToRemove = new List<Product>();

            foreach (var product in Cart)
            {
                if (remainingMoney < product.Price)
                {
                    productsToRemove.Add(product);
                }
                else
                {
                    remainingMoney -= product.Price;
                }
            }

            foreach (var product in productsToRemove)
            {
                Cart.Remove(product);
                Package.Add(product);
            }

            Console.WriteLine($"Покупатель {Name} не хватило денег на товары.");
            Console.WriteLine($"В пакете покупателя {Name} остались товары:");
            foreach (var product in Package)
            {
                Console.WriteLine(product.Name);
            }
        }
    }
}

public class Store
{
    public List<Product> Products { get; set; }

    public Store()
    {
        Products = new List<Product>();
    }

    public void SellProducts(Customer customer)
    {
        customer.BuyProducts();
    }
}

class Program
{
    static void Main(string[] args)
    {
        Store store = new Store();

        store.Products.Add(new Product("Яйца", 100));
        store.Products.Add(new Product("Мало подсолнечное", 200));
        store.Products.Add(new Product("Не придумал", 300));

        Customer customer = new Customer("Сергей", 1000);

        customer.AddProductToCart(store.Products[0]);
        customer.AddProductToCart(store.Products[1]);
        customer.AddProductToCart(store.Products[2]);

        Console.WriteLine($"Покупатель {customer.Name} хочет купить следующие товары:");
        foreach (var product in customer.Cart)
        {
            Console.WriteLine(product.Name);
        }

        store.SellProducts(customer);

        Console.WriteLine("Нажмите любую кнопку чтобы закончить работу...");
        Console.ReadKey();
    }
}