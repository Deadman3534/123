﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ConsoleApp6.GladiatorGameConstants;

namespace ConsoleApp6
{
    public abstract class Gladiator
    {
        public string Name { get; set; }
        public int Health { get; set; }
        public int Damage { get; set; }

        public Gladiator(string name)
        {
            Name = name;
            Health = GladiatorGameConstants.BaseHealth;
        }

        public abstract void Attack(Gladiator opponent);
    }
}
