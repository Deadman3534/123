﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    public class Warrior : Gladiator
    {
        public Warrior(string name) : base(name) { }

        public override void Attack(Gladiator opponent)
        {
            int damage = Damage;
            if (opponent is Warrior)
            {
                damage -= (int)(damage * 0.2); // partial damage absorption
            }
            opponent.Health -= damage;
            Console.WriteLine($"{Name} attacks {opponent.Name} for {damage} damage!");
        }
    }
}
