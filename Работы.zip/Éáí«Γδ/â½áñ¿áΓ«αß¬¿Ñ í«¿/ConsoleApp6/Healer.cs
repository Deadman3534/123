﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ConsoleApp6.GladiatorGameConstants;

namespace ConsoleApp6
{
    public class Healer : Gladiator
    {
        private Random _random = new Random();

        public Healer(string name) : base(name) { }

        public override void Attack(Gladiator opponent)
        {
            if (_random.NextDouble() < 0.2) // 20% chance to heal
            {
                Health += GladiatorGameConstants.BaseHealth / 2;
                Console.WriteLine($"{Name} heals themselves for {GladiatorGameConstants.BaseHealth / 2} health!");
            }
            else
            {
                opponent.Health -= Damage;
                Console.WriteLine($"{Name} attacks {opponent.Name} for {Damage} damage!");
            }
        }
    }
}
