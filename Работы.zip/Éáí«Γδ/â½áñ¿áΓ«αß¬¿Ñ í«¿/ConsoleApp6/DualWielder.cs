﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    public class DualWielder : Gladiator
    {
        private Random _random = new Random();

        public DualWielder(string name) : base(name) { }

        public override void Attack(Gladiator opponent)
        {
            if (_random.NextDouble() < 0.5) // 50% chance to dual wield
            {
                opponent.Health -= Damage * 2;
                Console.WriteLine($"{Name} dual wields and attacks {opponent.Name} for {Damage * 2} damage!");
            }
            else
            {
                opponent.Health -= Damage;
                Console.WriteLine($"{Name} attacks {opponent.Name} for {Damage} damage!");
            }
        }
    }
}
