﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ConsoleApp6.GladiatorGameConstants;

namespace ConsoleApp6
{
    public class Mage : Gladiator
    {
        private int _mana;

        public Mage(string name) : base(name)
        {
            _mana = GladiatorGameConstants.Mana;
        }

        public override void Attack(Gladiator opponent)
        {
            if (_mana > 0)
            {
                opponent.Health -= GladiatorGameConstants.SpecialAttackDamage;
                _mana -= 10;
                Console.WriteLine($"{Name} casts a spell and attacks {opponent.Name} for {GladiatorGameConstants.SpecialAttackDamage} damage!");
            }
            else
            {
                opponent.Health -= Damage / 2;
                Console.WriteLine($"{Name} attacks {opponent.Name} for {Damage / 2} damage!");
            }
        }
    }
}
