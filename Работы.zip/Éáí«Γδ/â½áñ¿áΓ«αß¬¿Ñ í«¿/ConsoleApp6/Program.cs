﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    class Program
    {
        static void Main(string[] args)
        {
            Gladiator warrior = new Warrior("Warrior");
            Gladiator dualWielder = new DualWielder("Dual Wielder");
            Gladiator mage = new Mage("Mage");
            Gladiator healer = new Healer("Healer");
            Gladiator berserker = new Berserker("Berserker");

            Gladiator[] gladiators = new Gladiator[] { warrior, dualWielder, mage, healer, berserker };

            Console.WriteLine("Начинаем бой!");
            Console.WriteLine("Если хотите пропустить бой, нажмите 'p', если хотите посмотреть бой, нажмите любую другую клавишу.");
            string input = Console.ReadLine();

            if (input.ToLower() == "p")
            {
                Console.WriteLine("Пропускаем бой...");
                Gladiator winner = GetWinner(gladiators);
                Console.WriteLine($"The winner is {winner.Name}!");
                Console.WriteLine($"Окончательный результат:");
                Console.WriteLine($"{winner.Name} остался в живых с {winner.Health} здоровья.");
            }
            else
            {
                while (true)
                {
                    foreach (var gladiator in gladiators)
                    {
                        if (gladiator.Health <= 0)
                        {
                            Console.WriteLine($"{gladiator.Name} has been defeated!");
                            gladiators = gladiators.Where(g => g != gladiator).ToArray();
                        }
                        else
                        {
                            int opponentIndex = new Random().Next(gladiators.Length);
                            Gladiator opponent = gladiators[opponentIndex];
                            while (opponent == gladiator)
                            {
                                opponentIndex = new Random().Next(gladiators.Length);
                                opponent = gladiators[opponentIndex];
                            }
                            gladiator.Attack(opponent);
                        }
                    }

                    if (gladiators.Length == 1)
                    {
                        Console.WriteLine($"The winner is {gladiators[0].Name}!");
                        Console.WriteLine($"Окончательный результат:");
                        Console.WriteLine($"{gladiators[0].Name} остался в живых с {gladiators[0].Health} здоровья.");
                        break;
                    }
                }
            }

            Console.WriteLine("Нажмите любую кнопку чтобы закончить работу...");
            Console.ReadKey();
        }

        static Gladiator GetWinner(Gladiator[] gladiators)
        {
            while (gladiators.Length > 1)
            {
                foreach (var gladiator in gladiators)
                {
                    if (gladiator.Health <= 0)
                    {
                        gladiators = gladiators.Where(g => g != gladiator).ToArray();
                    }
                    else
                    {
                        int opponentIndex = new Random().Next(gladiators.Length);
                        Gladiator opponent = gladiators[opponentIndex];
                        while (opponent == gladiator)
                        {
                            opponentIndex = new Random().Next(gladiators.Length);
                            opponent = gladiators[opponentIndex];
                        }
                        gladiator.Attack(opponent);
                    }
                }
            }
            return gladiators[0];
        }
            
    }

}
        
    
