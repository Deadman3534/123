﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ConsoleApp6.GladiatorGameConstants;

namespace ConsoleApp6
{
    public class Berserker : Gladiator
    {
        public Berserker(string name) : base(name) { }

        public override void Attack(Gladiator opponent)
        {
            if (Health < GladiatorGameConstants.BaseHealth * 0.2)
            {
                opponent.Health -= Damage * 2;
                Console.WriteLine($"{Name} enters a berserker rage and attacks {opponent.Name} for {Damage * 2} damage!");
            }
            else
            {
                opponent.Health -= Damage;
                Console.WriteLine($"{Name} attacks {opponent.Name} for {Damage} damage!");
            }
        }
    }
}
