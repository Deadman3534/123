﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    public static class GladiatorGameConstants
    {
        public static int BaseHealth = 100;
        public static int BaseDamage = 20;
        public static int Mana = 50;
        public static int SpecialAttackDamage = 40;
        public static int HealthThreshold = 20;
    }
}
